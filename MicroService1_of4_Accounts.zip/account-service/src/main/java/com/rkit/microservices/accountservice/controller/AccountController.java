package com.rkit.microservices.accountservice.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rkit.microservices.accountservice.entity.Account;
import com.rkit.microservices.accountservice.service.AccountService;

import lombok.extern.slf4j.Slf4j;

@RestController
@RequestMapping("/accounts")
@Slf4j
public class AccountController {
	
	Logger logger = LoggerFactory.getLogger(AccountController.class);
	
	@Autowired
	AccountService accountService;
	
	@PostMapping("/create")
	public Object createAccount(@RequestBody Account acct) {
		
		System.out.println("Inside post");
		return accountService.saveAccount(acct);
	}
	@GetMapping("/{id}")
	public Account getAccount(@PathVariable("id") long id) {
		logger.info("DEBUG : getAccount ");
		return accountService.findAccountById(id);
	}
	@GetMapping("/")
	public List<Account> getAllAccounts() {
		logger.info("DEBUG : getAccount ");
		return accountService.findAll();
	}

}
