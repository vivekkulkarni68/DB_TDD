package com.rkit.microservices.accountservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rkit.microservices.accountservice.entity.Account;
import com.rkit.microservices.accountservice.repository.AccountRepository;

@Service
public class AccountService {
	
	@Autowired
	AccountRepository repository;

	public Object saveAccount(Account acct) {
		// TODO Auto-generated method stub
		return repository.save(acct);
	}

	public Account findAccountById(long id) {
		// TODO Auto-generated method stub
		return repository.getAccountById(id);
	}

	public List<Account> findAll() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

	

}
