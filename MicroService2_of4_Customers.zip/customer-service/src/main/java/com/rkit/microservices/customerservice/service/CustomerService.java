package com.rkit.microservices.customerservice.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.rkit.microservices.customerservice.entity.Account;
import com.rkit.microservices.customerservice.entity.Customer;
import com.rkit.microservices.customerservice.repository.CustomerRepository;

@Service
public class CustomerService {
	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	CustomerRepository repository;
	public List<Account> getAccountsById(int custId){
	//	Customer customer = repository.findById(custId).get();
		ResponseEntity<Account[]> accountsEntity = restTemplate.getForEntity("http://ACCOUNT-SERVICE/accounts/",Account[].class);
		Account[] allAccounts = accountsEntity.getBody();
		List<Account> matchingAccounts = new ArrayList<Account>();
		for(Account acct : allAccounts) {
			if(acct.getCustId()==custId) {
				matchingAccounts.add(acct);
			}
		}
		return matchingAccounts;
	}
	public List<Customer> getCustomers() {
		return repository.findAll();
	}
	public Customer createCustomer(Customer customer) {
		return repository.save(customer);	
	}

}
