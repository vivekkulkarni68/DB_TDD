package com.rkit.microservices.customerservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rkit.microservices.customerservice.entity.Account;
import com.rkit.microservices.customerservice.entity.Customer;
import com.rkit.microservices.customerservice.service.CustomerService;

@RestController
@RequestMapping("/customers")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@PostMapping("/create")
	public Customer createNewCustomer(@RequestBody Customer customer) {
		return customerService.createCustomer(customer);
	}
	@GetMapping("/")
	public List<Customer> getAllCustomers(){
		return customerService.getCustomers();
	}
	@GetMapping("/{id}")
	public List<Account> getAccountsByCustomerId(@PathVariable("id") int id){
		return customerService.getAccountsById(id);	
	}

}
