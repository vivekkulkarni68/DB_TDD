package com.rkit.microservices.customerservice.entity;

import javax.persistence.Embeddable;

@Embeddable
public class Account {
	int custId;
	public int getCustId() {
		return custId;
	}
	public void setCustId(int custId) {
		this.custId = custId;
	}
	long id;
	String name;
	String  city;
	int pin;
	double balance;
	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Account(long id, String name, String city, int pin, double balance) {
		super();
		this.id = id;
		this.name = name;
		this.city = city;
		this.pin = pin;
		this.balance = balance;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	

}
