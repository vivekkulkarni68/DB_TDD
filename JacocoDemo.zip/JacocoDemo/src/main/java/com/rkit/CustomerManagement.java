package com.rkit;

public class CustomerManagement {
	
	
	public String addCustomer(String name,String address, int age){
		if(name!=null && address!=null) {
			if(age>18)
			return "CustomerAdded";
			else
				return "Failed";
		}else {
			return "Failed";
		}
	}
	
	public void m1() {}

}
