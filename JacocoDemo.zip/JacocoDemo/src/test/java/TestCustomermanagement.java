import static org.junit.Assert.*;

import org.junit.Test;

import com.rkit.CustomerManagement;

public class TestCustomermanagement {

	@Test
	public void testAddCustomer() {
		CustomerManagement c = new CustomerManagement();
		String retVal = c.addCustomer("Vivek", "Pune", 20);
		assertEquals(retVal,"CustomerAdded");
		
	}
	@Test
	public void testAddCustomerErrorPath1() {
		CustomerManagement c = new CustomerManagement();
		String retVal = c.addCustomer("Vivek", null, 20);
		assertEquals(retVal,"Failed");
		
	}
	@Test
	public void testAddCustomerErrorPath2() {
		CustomerManagement c = new CustomerManagement();
		String retVal = c.addCustomer(null, "Pune", 20);
		assertEquals(retVal,"Failed");
		
	}
	@Test
	public void testAddCustomerErrorPathAge() {
		CustomerManagement c = new CustomerManagement();
		String retVal = c.addCustomer("Vivek", "Pune", 17);
		assertEquals(retVal,"Failed");
		
	}


}
